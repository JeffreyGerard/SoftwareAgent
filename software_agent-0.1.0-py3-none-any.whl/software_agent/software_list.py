APPROVED_SOFTWARE_LIST = [
     "Microsoft Office",
     "Adobe Acrobat Pro",
     "Google Chrome",
     "Mozilla Firefox",
     "Zoom",
     "Slack",
     "Visual Studio Code"
 ]